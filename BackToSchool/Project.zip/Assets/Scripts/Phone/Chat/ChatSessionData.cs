using System;
using System.Collections.Generic;
using UnityEngine;

public enum ChatSender { Other, Me }

[Serializable]
public class ChatLine
{
    public ChatSender sender;
    [TextArea(2, 6)] public string text;

    [Tooltip("Other�� �ڵ�, Me�� ���ؾ� ����")]
    public bool requireTapToSend;

    [Min(0f)] public float delay = 0.6f; // �ڵ� �޽��� �� ������
}

[CreateAssetMenu(menuName = "Game/Chat/Chat Session")]
public class ChatSessionData : ScriptableObject
{
    public string sessionId;
    public string roomId;

    public List<ChatLine> lines = new();
}
